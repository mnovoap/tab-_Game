# Tabú

Juego de Tabú para celular (iPhone y Android), hecho como PWA: una página web que se instala como app y funciona sin internet.

Archivos:
- `index.html`: toda la app (pantallas, estilos y lógica).
- `manifest.webmanifest`: nombre, colores e íconos de la app instalada.
- `sw.js`: permite usarla sin conexión. Si cambias algún archivo, sube la versión `tabu-v1` → `tabu-v2`.
- `icons/`: íconos de la app.

Las tarjetas de ejemplo están al principio del `<script>` de `index.html` (constante `EXAMPLES`).
